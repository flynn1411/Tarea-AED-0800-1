function Lapiz(marca, tipo){
    this.marca = marca;
    this.tipo = tipo;
}
        

function ResmaDePapel(marca, tipo, cantidad){
    this.marca = marca;
    this.tipo = tipo;
    this.cantidad = cantidad;
}
        
function Clips(cantidad, tamañoClip){
    this.cantidad = cantidad;
    this.tamañoClip = tamañoClip;
}
        

function Grapadora(marca, capacidad){
    this.marca = marca;
    this.capacidad = capacidad;
}
        

function Grapas(cantidad, tamañoGrapa){
    this.cantidad = cantidad;
    this.tamañoGrapa = tamañoGrapa;
}
        

function Folder(tipo, material){
    this.tipo = tipo;
    this.material = material;
}
        

function PostIts(color, cantidad){
    this.color = color;
    this.cantidad = cantidad;
}
        

function Marcador(marca, tipo){
    this.marca = marca;
    this.tipo = tipo;
}
        

function Borrador(marca, tipo){
    this.marca = marca;
    this.tipo = tipo;
}
        

function Corrector(marca, tipo){
    this.marca = marca;
    this.tipo = tipo;
}
        

function CintaAdhesiva(marca, tipo){
    this.marca = marca;
    this.tipo = tipo;
}
        