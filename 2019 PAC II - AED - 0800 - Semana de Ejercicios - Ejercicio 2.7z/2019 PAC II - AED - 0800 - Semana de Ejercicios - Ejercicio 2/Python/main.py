from Directory import *

directory = Directory()
directory.mainMenu()