class Contact:
    def __init__(self,name,number):
        self.name = name
        self.number = number