function Contact(name, number){
    this.name = name;
    this.number = number;
}